var express = require('express');
var router = express.Router();
var createAcedamic = require('../models/C-stud');
router.post('/create', function(req,res,next) {
      var createacedamic = new createAcedamic({
      name: req.body.name,
      class: req.body.class,
      section: req.body.section,
      branch:  req.body.branch,
      totalpercent: req.body. totalpercent,
      collegename : req.body.collegename ,
});
  
    let promise = createacedamic.save();
    promise.then(function(doc) {
      return res.status(201).json(doc);
    })
  
    promise.catch(function(err){
      return res.status(501).json({message: 'Error adding tour'})
    })
  }); 
  module.exports = router;
