import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Acedamic } from '../acedamic';
@Component({
  selector: 'app-create-student',
  templateUrl: './create-student.component.html',
  styleUrls: ['./create-student.component.css']
})
export class CreateStudentComponent implements OnInit {
  stud : Acedamic = {
    name : "",
    class: "",
    section : "",
    branch : " ",
    totalpercent : null ,
    collegename : "",
    
    
  };
  constructor(private service: ApiService) { }

  ngOnInit() {
  }
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }
}
