export class Acedamic{
    class: string;
    name: string;
    section : string;
    branch : string;
    totalpercent : number;
    collegename : string;
    

}
