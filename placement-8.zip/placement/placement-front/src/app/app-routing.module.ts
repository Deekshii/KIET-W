import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ManagementComponent } from './management/management.component';
import { ViewManagementComponent } from './management/view-management/view-management.component';
import { OfficerComponent } from './officer/officer.component';
import { CreateOfficerComponent } from './officer/create-officer/create-officer.component';
import { ViewOfficerComponent } from './officer/view-officer/view-officer.component';
import { ViewStudentComponent } from './student/view-student/view-student.component';
import { StudentComponent } from './student/student.component';


const routes: Routes = [
  { path: 'o_create',    component: CreateOfficerComponent },
  { path: 'o_edit',    component: ViewOfficerComponent},
  { path: 'm_edit',    component: ViewManagementComponent},
  { path: 's_edit',    component: ViewStudentComponent},
  { path: 'm',    component: ManagementComponent },
  { path: 'o',    component: OfficerComponent },
  { path: 's',    component: StudentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
