import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
import { Nss } from '../nss';
@Component({
  selector: 'app-create-nss',
  templateUrl: './create-nss.component.html',
  styleUrls: ['./create-nss.component.css']
})
export class CreateNssComponent implements OnInit {
  stud : Nss = {
    name : "",
    class: "",
    section : "",
    branch : " ",
    hobbies : "" ,
    dob : null ,
    gender : "",
    collegename : "",
    fathername: "",
    phonenumber: null,
    community :  "",
    address: "",
  };
  constructor(private service: ApiService) { }
  ngOnInit() {
  }
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }
}
