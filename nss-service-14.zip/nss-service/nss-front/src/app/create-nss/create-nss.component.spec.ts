import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateNssComponent } from './create-nss.component';

describe('CreateNssComponent', () => {
  let component: CreateNssComponent;
  let fixture: ComponentFixture<CreateNssComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateNssComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateNssComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
