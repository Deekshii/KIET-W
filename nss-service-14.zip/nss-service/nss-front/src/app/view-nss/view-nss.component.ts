import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service';
@Component({
  selector: 'app-view-nss',
  templateUrl: './view-nss.component.html',
  styleUrls: ['./view-nss.component.css']
})
export class ViewNssComponent implements OnInit {

  stud
  val:boolean = true ; 
  expandedIndex: any
  constructor(private service: ApiService ) { }

  delete(val){
    var v={
      "_id":val._id
    }
    console.log(v)
    this.service.del(v).subscribe(res => {
      console.log(res)   
   })
  }
  ngOnInit() {
    console.log('hello');
   this.getAllNss();
  }
//gets data from db
  getAllNss () {
    console.log('hi');
    this.service.getnss().subscribe((res: any) => {
      this.stud = res
      console.log(res);
    }, err => {
      console.log(err);
    })
  }
//edit the data
    public edit(data, index) {
    this.expandedIndex = index;
  }
  //saves edited data
  public save(data) {
     this.service.add(data).subscribe((data) => {
       console.log(data)
       this.val = true
     })
    } 
}
