import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewNssComponent } from './view-nss/view-nss.component';
import { CreateNssComponent } from './create-nss/create-nss.component';


const routes: Routes = [
  { path: 'create',    component: CreateNssComponent },
  { path: 'edit',    component: ViewNssComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
