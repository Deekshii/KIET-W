export class Nss {
    class: string;
    name: string;
    section : string;
    branch : string;
    hobbies : string;
    gender : string;
    fathername : string;
    community : string;
    dob : number;
    collegename : string;
    phonenumber: number;
    address : string;
    

}
