
var express = require('express');
var router = express.Router();

var ReadNss = require('../models/C-stud');

router.put('/edit', (req, res) => {
    console.log(req.body)  
      if (!req.body._id){
        return res.status(400).send(`No record with given id : ${req.body._id}`);
      }
       var data=new  ReadNss()
        var data = {
            name:  req.body.name,
            class:  req.body.class,
            section:  req.body.section,
            branch:  req.body.branch,
            hobbies:  req.body.hobbies,
            dob : req.body.dob,  
            gender:  req.body.gender,
            collegename : req.body.collegename, 
            fathername:  req.body.fathername,
            phonenumber:  req.body.phonenumber,
            community : req.body.community,
            address: req.body.address,
            
        };      
        ReadNss.updateOne({"_id":req.body._id}, { $set: data }, { new: true }, (err, doc) => {
            if (!err)
            { res.send(doc);
                console.log(doc) 
            }
            else { console.log('Error in tour Update :' + JSON.stringify(err, undefined, 2)); }
        });   
});


module.exports = router;

