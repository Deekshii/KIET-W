var mongoose = require('mongoose');
var Schema = mongoose.Schema;
//  var Subscribe = mongoose.Subscribe;

var schema = new Schema({
    name: {type:String, require:true},
    class: {type:String, require:true},
    section: {type:String, require:true},
    branch: {type:String, require:true},
    hobbies: {type:String, require:true},
    dob :{type:Number, require:true},  
    gender: {type:String, require:true},
    collegename :{type:String, require:true}, 
    fathername: {type:String, require:true},
    phonenumber: {type:Number, require:true},
    community :{type:String, require:true},
    address: {type:String, require:true},
    
});
module.exports = mongoose.model('create', schema );
