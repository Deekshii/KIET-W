import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ManagementComponent } from './management/management.component';
import { FormsModule,  ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { CreateComponent } from './management/create/create.component';
import { ViewComponent } from './management/view/view.component';

import { StudentComponent } from './student/student.component';
import { StudentViewComponent } from './student/student-view/student-view.component';


@NgModule({
  declarations: [
    AppComponent,
    ManagementComponent,
    CreateComponent,
    ViewComponent,
    StudentComponent,
    StudentViewComponent,
   
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
