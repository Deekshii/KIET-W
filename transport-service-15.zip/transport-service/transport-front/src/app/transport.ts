export class Transport {
    email: string;
    phonenumber: Number;
    name: string;
    busnumber: Number;
    dateofbirth : Date;
    address: string;
    branch:  string;
    department : string;
    dateofjoining : Date;
    gender : string;
    collegename : string;
    

}
