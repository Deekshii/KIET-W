import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { Transport } from 'src/app/transport';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {

  stud : Transport= {
    email : "",
    phonenumber : null,
    name: "",
    busnumber: null,
    dateofbirth : null,
    branch: "",
    address: "",
    department : "",
    dateofjoining : null,
    gender : "",
    collegename: "",
    
  };

  constructor( private service: ApiService) { }

  ngOnInit() {
  }
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }
}
