import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManagementComponent } from './management/management.component';
import { CreateComponent } from './management/create/create.component';
import { ViewComponent } from './management/view/view.component';
import { StudentComponent } from './student/student.component';
import { StudentViewComponent } from './student/student-view/student-view.component';


const routes: Routes = [
  { path: 'm_create',    component: CreateComponent },
  { path: 'm_view',    component: ViewComponent },
  { path: 'm',    component: ManagementComponent },
  { path: 's',    component: StudentComponent },
  
  { path: 's_edit',    component: StudentViewComponent },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
