
var express = require('express');
var router = express.Router();

var ReadTransport = require('../models/C-stud');

router.put('/edit', (req, res) => {
    console.log(req.body)  
      if (!req.body._id){
        return res.status(400).send(`No record with given id : ${req.body._id}`);
      }
       var data=new  ReadFaculty()
        var data = {
          email: req.body. email,
          // password: req.body.  password,
           name: req.body.firstname,
           busnumber: req.body.busnumber,
          phonenumber: req.body.phonenumber,
           dateofbirth:  req.body.dateofbirth,
           address: req.body.address,
           //age: req.body.age,
           branch: req.body.branch,
           department: req.body.department,
           dateofjoining:  req.body.dateofjoining,
           gender: req.body.gender,
           collegename : req.body.collegename ,
        };       
        ReadTransport.updateOne({"_id":req.body._id}, { $set: data }, { new: true }, (err, doc) => {
            if (!err)
            { res.send(doc);
                console.log(doc) 
            }
            else { console.log('Error in tour Update :' + JSON.stringify(err, undefined, 2)); }
        });   
});


module.exports = router;

