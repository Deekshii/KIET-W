var express = require('express');
var router = express.Router();
var createTransport = require('../models/C-stud');
router.post('/create', function(req,res,next) {
      var createtransport = new createTransport({
      email: req.body. email,
     // password: req.body.  password,
      name: req.body.firstname,
      busnumber: req.body.busnumber,
     phonenumber: req.body.phonenumber,
      dateofbirth:  req.body.dateofbirth,
      address: req.body.address,
      //age: req.body.age,
      branch: req.body.branch,
      department: req.body.department,
      dateofjoining:  req.body.dateofjoining,
      gender: req.body.gender,
      collegename : req.body.collegename ,
});
  
    let promise = createtransport.save();
    promise.then(function(doc) {
      return res.status(201).json(doc);
    })
  
    promise.catch(function(err){
      return res.status(501).json({message: 'Error adding tour'})
    })
  }); 
  module.exports = router;
