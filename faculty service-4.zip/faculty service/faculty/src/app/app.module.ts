import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,  ReactiveFormsModule } from '@angular/forms';
 import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';


import { ManagementComponent } from './management/management.component';
import { StudentComponent } from './student/student.component';
import { ViewStudentComponent } from './student/view-student/view-student.component';
import { CreateStudentComponent } from './student/create-student/create-student.component';
import { FacultyComponent } from './faculty/faculty.component';
import { CreateComponent } from './management/create/create.component';
import { ViewComponent } from './management/view/view.component';
import { CreateFacultyComponent } from './faculty/create-faculty/create-faculty.component';
import { ViewFacultyComponent } from './faculty/view-faculty/view-faculty.component';



@NgModule({
  declarations: [
    AppComponent,
 
    ManagementComponent,
    StudentComponent,
    ViewStudentComponent,
    CreateStudentComponent,
    FacultyComponent,
    CreateComponent,
    ViewComponent,
    ViewFacultyComponent,
    CreateFacultyComponent,
 
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
