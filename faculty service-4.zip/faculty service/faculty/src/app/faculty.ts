export class Faculty {
    email: string;
    phonenumber: number;
    firstname: string;
    lastname: string;
    dateofbirth : Date;
   age : Number;
    address: string;
    speciliazedin : string;
    department : string;
    dateofjoining : Date;
    gender : string;
    collegename : string;
    

}
