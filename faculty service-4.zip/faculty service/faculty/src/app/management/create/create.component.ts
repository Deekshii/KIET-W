import { Component, OnInit } from '@angular/core';
import { Faculty } from 'src/app/faculty';
import { ApiService } from 'src/app/api.service';

@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
  stud : Faculty= {
    email : "",
    phonenumber: null,
    firstname: "",
    lastname: "",
    dateofbirth : null,
    age:null ,
    address: "",
    speciliazedin : "",
    department : "",
    dateofjoining : null,
    gender : "",
    collegename: "",
    
  };
  constructor(private service: ApiService) { }
  ngOnInit() {
  } 
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }

}

