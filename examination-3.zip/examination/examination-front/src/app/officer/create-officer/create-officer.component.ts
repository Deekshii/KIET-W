import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { Placement } from 'src/app/placement';
// import { Placement } from 'src/app/placement';

@Component({
  selector: 'app-create-officer',
  templateUrl: './create-officer.component.html',
  styleUrls: ['./create-officer.component.css']
})
export class CreateOfficerComponent implements OnInit {
  stud: Placement= {
    studentname: "",
    studentclass: "",
    studentbranch: "",
      studentsection: "",
      studentid: "",
      studentacademicpercentage: "",
      examstimetable: "",
  };
  constructor(private service: ApiService) { }
  ngOnInit() {
  } 
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }

}