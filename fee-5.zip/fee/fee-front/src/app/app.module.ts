import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,  ReactiveFormsModule } from '@angular/forms';
 import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { OfficerComponent } from './officer/officer.component';
import { CreateComponent } from './officer/create/create.component';
import { ViewComponent } from './officer/view/view.component';
import { ManagementComponent } from './management/management.component';
import { ViewManagemenComponent } from './management/view-managemen/view-managemen.component';


@NgModule({
  declarations: [
    AppComponent,
    ManagementComponent,
    ViewComponent,
    OfficerComponent,
    CreateComponent,
    ViewComponent,
    ViewManagemenComponent,
 
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
