export class Fee {
    studentname: string;
    studentclass: string;
    studentbranch: string;
      studentsection: string;
      studentid: number;
      studentfeedetails: string;
}