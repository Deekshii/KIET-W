export class Event  {
    location : string;
    eventname: string;
    eventdate: Date;
    description : string;
   

}
