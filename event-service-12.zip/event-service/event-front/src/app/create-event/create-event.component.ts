import { Component, OnInit } from '@angular/core';
import { Event } from '../event';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-create-event',
  templateUrl: './create-event.component.html',
  styleUrls: ['./create-event.component.css']
})
export class CreateEventComponent implements OnInit {

  stud : Event = {
    
   eventname: "",
    location : "",
    description: "",
    eventdate : null ,
    
    
  };
  
  constructor(private service: ApiService) { }
  ngOnInit() {
  } 
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }

}
