import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewEventComponent } from './view-event/view-event.component';
import { CreateEventComponent } from './create-event/create-event.component';


const routes: Routes = [
  { path: 'create',    component: CreateEventComponent },
  { path: 'edit',    component: ViewEventComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
