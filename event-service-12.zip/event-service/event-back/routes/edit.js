
var express = require('express');
var router = express.Router();

var ReadEvent = require('../models/C-stud');

router.put('/edit', (req, res) => {
    console.log(req.body)  
      if (!req.body._id){
        return res.status(400).send(`No record with given id : ${req.body._id}`);
      }
       var data=new  ReadEvent()
        var data = {
            eventname: req.body.eventname,
            eventdate: req.body.eventdate,
            description: req.body.description,
            location: req.body.location,
        };      
        ReadEvent.updateOne({"_id":req.body._id}, { $set: data }, { new: true }, (err, doc) => {
            if (!err)
            { res.send(doc);
                console.log(doc) 
            }
            else { console.log('Error in tour Update :' + JSON.stringify(err, undefined, 2)); }
        });   
});


module.exports = router;

