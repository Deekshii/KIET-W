var express = require('express');
var router = express.Router();
var createEvent = require('../models/C-stud');
router.post('/create', function(req,res,next) {
      var createevent = new createEvent({
      eventname: req.body.eventname,
      eventdate: req.body.eventdate,
      description: req.body.description,
     location: req.body.location,
});
  
    let promise = createevent.save();
    promise.then(function(doc) {
      return res.status(201).json(doc);
    })
  
    promise.catch(function(err){
      return res.status(501).json({message: 'Error adding tour'})
    })
  }); 
  module.exports = router;
