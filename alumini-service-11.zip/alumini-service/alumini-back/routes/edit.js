var express = require('express');
var router = express.Router();
var ReadAlumini = require('../models/C-stud');
router.put('/edit', (req, res) => {
    console.log(req.body)  
      if (!req.body._id){
        return res.status(400).send(`No record with given id : ${req.body._id}`);
      }
       var data=new  ReadAlumini()
        var data = {
            email: req.body. email,
            alumininame: req.body.alumininame,
            organisationworking: req.body.organisationworking,
            location:  req.body.location,
            phonenumber: req.body.phonenumber,
        };       
        ReadAlumini.updateOne({"_id":req.body._id}, { $set: data }, { new: true }, (err, doc) => {
            if (!err)
            { res.send(doc);
                console.log(doc) 
            }
            else { console.log('Error in tour Update :' + JSON.stringify(err, undefined, 2)); }
        });   
});
module.exports = router;

