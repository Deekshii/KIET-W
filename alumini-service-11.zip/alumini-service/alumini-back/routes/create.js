var express = require('express');
var router = express.Router();
var createAlumini = require('../models/C-stud');
router.post('/create', function(req,res,next) {
    var createalumini = new createAlumini({
      email: req.body. email,
      alumininame: req.body.alumininame,
      organisationworking: req.body.organisationworking,
      location:  req.body.location,
      phonenumber: req.body.phonenumber,   
});
    let promise = createalumini.save();
    promise.then(function(doc) {
      return res.status(201).json(doc);
    })
    promise.catch(function(err){
      return res.status(501).json({message: 'Error adding tour'})
    })
  }); 
  module.exports = router;
