export class Alumini {
    email: string;
    alumininame: string;
    organisationworking : string;
    location : string;
    phonenumber : number;
    

}
