import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateAluminiComponent } from './create-alumini/create-alumini.component';
import { ViewAluminiComponent } from './view-alumini/view-alumini.component';


const routes: Routes = [
  { path: 'create',    component: CreateAluminiComponent },
  { path: 'edit',    component: ViewAluminiComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
