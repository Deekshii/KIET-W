import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api.service'; 

@Component({
  selector: 'app-view-alumini',
  templateUrl: './view-alumini.component.html',
  styleUrls: ['./view-alumini.component.css']
})
export class ViewAluminiComponent implements OnInit {

  stud
  val:boolean = true ; 
  expandedIndex: any
  constructor(private service: ApiService) { }

  delete(val){
    var v={
      "_id":val._id
    }
    console.log(v)
    this.service.del(v).subscribe(res => {
      console.log(res)   
   })
  }
  ngOnInit() {
    console.log('hello');
   this.getAllAlumini();
  }
//gets data from db
  getAllAlumini () {
    console.log('hi');
    this.service.getalumini().subscribe((res: any) => {
      this.stud = res
      console.log(res);
    }, err => {
      console.log(err);
    })
  }
//edit the data
    public edit(data, index) {
    this.expandedIndex = index;
  }
  //saves edited data
  public save(data) {
     this.service.add(data).subscribe((data) => {
       console.log(data)
       this.val = true
     })
    } 

}
