import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewAluminiComponent } from './view-alumini.component';

describe('ViewAluminiComponent', () => {
  let component: ViewAluminiComponent;
  let fixture: ComponentFixture<ViewAluminiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewAluminiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewAluminiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
