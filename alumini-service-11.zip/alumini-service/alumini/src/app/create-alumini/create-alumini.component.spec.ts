import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateAluminiComponent } from './create-alumini.component';

describe('CreateAluminiComponent', () => {
  let component: CreateAluminiComponent;
  let fixture: ComponentFixture<CreateAluminiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateAluminiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateAluminiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
