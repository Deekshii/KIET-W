import { Component, OnInit } from '@angular/core';
import { Alumini } from '../alumini';
import { ApiService } from '../api.service';

@Component({
  selector: 'app-create-alumini',
  templateUrl: './create-alumini.component.html',
  styleUrls: ['./create-alumini.component.css']
})
export class CreateAluminiComponent implements OnInit {
  stud : Alumini = {
    email : "",
    alumininame: "",
    organisationworking : "",
    location : " ",
    phonenumber : null ,
    
    
  };
  
  constructor(private service: ApiService) { }
  ngOnInit() {
  } 
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }
}

















  
 
 

