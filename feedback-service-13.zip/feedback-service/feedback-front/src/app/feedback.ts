export class Feedback {
   feedback: string;
    rollnumber : Number;
    

}
