import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewFeedbackComponent } from './view-feedback/view-feedback.component';
import { CreateFeedbackComponent } from './create-feedback/create-feedback.component';


const routes: Routes = [
  { path: 'create',    component: CreateFeedbackComponent },
  { path: 'edit',    component: ViewFeedbackComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
