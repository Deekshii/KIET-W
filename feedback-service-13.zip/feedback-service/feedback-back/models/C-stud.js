var mongoose = require('mongoose');
var Schema = mongoose.Schema;
//  var Subscribe = mongoose.Subscribe;

var schema = new Schema({
  
    rollnumber:{type:Number, require:true},
    feedback : {type:String, require:true},
   
});
module.exports = mongoose.model('create', schema );
