var express = require('express');
var router = express.Router();
var createFeedback = require('../models/C-stud');
router.post('/create', function(req,res,next) {
      var createfeedback = new createFeedback({
      
      rollnumber: req.body.rollnumber,
      feedback: req.body.feedback,
     
});
  
    let promise = createfeedback.save();
    promise.then(function(doc) {
      return res.status(201).json(doc);
    })
  
    promise.catch(function(err){
      return res.status(501).json({message: 'Error adding tour'})
    })
  }); 
  module.exports = router;