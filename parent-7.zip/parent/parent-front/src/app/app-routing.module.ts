import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ManagementComponent } from './management/management.component';
import { ViewManagementComponent } from './management/view-management/view-management.component';

import { ViewStudentComponent } from './student/view-student/view-student.component';
import { StudentComponent } from './student/student.component';
import { ParentComponent } from './parent/parent.component';
import { CreateComponent } from './management/create/create.component';


const routes: Routes = [
  { path: 'm_create',    component: CreateComponent },
  { path: 'm_edit',    component: ViewManagementComponent},
  { path: 'p_edit',    component: ViewManagementComponent},
  { path: 's_edit',    component: ViewStudentComponent},
  { path: 'm',    component: ManagementComponent },
  { path: 'p',    component: ParentComponent },
  { path: 's',    component: StudentComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
