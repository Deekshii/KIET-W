export class Canteen {
    itemname: string;
     price : Number;
     
 
 }
 