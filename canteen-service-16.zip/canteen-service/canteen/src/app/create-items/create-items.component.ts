import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { Canteen } from '../canteen';
@Component({
  selector: 'app-create-items',
  templateUrl: './create-items.component.html',
  styleUrls: ['./create-items.component.css']
})
export class CreateItemsComponent implements OnInit {

  stud : Canteen = {
    
    itemname : "",
    price : null,
  
  };

  constructor( private service: ApiService) { }

  ngOnInit() {
  }
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }
}
