import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateItemsComponent } from './create-items/create-items.component';
import { ViewItemsComponent } from './view-items/view-items.component';
import { StudentViewComponent } from './student-view/student-view.component';

const routes: Routes = [  
  { path: 'create',    component: CreateItemsComponent },
   { path: 'edit',    component: ViewItemsComponent},
   { path: 's_edit',    component: StudentViewComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
