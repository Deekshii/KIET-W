var express = require('express');
var router = express.Router();
var ReadCanteen = require('../models/C-stud');
router.put('/edit', (req, res) => {
    console.log(req.body)  
      if (!req.body._id){
        return res.status(400).send(`No record with given id : ${req.body._id}`);
      }
       var data=new  ReadCanteen()
        var data = {
            itemname: req.body.itemname,
            price: req.body.price,
        };       
        ReadCanteen.updateOne({"_id":req.body._id}, { $set: data }, { new: true }, (err, doc) => {
            if (!err)
            { res.send(doc);
                console.log(doc) 
            }
            else { console.log('Error in tour Update :' + JSON.stringify(err, undefined, 2)); }
        });   
});


module.exports = router;

