import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,  ReactiveFormsModule } from '@angular/forms';
 import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { ManagementComponent } from './management/management.component';
import { StudentComponent } from './student/student.component';

import { AdmissionOfficerComponent } from './admission-officer/admission-officer.component';
import { CreateAdmissionComponent } from './admission-officer/create-admission/create-admission.component';
import { ViewAdmissionComponent } from './admission-officer/view-admission/view-admission.component';

import { ViewComponent } from './student/view/view.component';


@NgModule({
  declarations: [
    AppComponent,

    ManagementComponent,
    StudentComponent,
  
    AdmissionOfficerComponent,
    CreateAdmissionComponent,
    ViewAdmissionComponent,
    
    ViewComponent,
 
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
