import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { AdmissionOfficerComponent } from './admission-officer/admission-officer.component';
import { StudentComponent } from './student/student.component';
import { ViewComponent } from './student/view/view.component';
import { CreateAdmissionComponent } from './admission-officer/create-admission/create-admission.component';
import { ViewAdmissionComponent } from './admission-officer/view-admission/view-admission.component';



const routes: Routes = [

  { path: 's_edit',    component: ViewComponent}, 
  { path: 'a_create',    component:CreateAdmissionComponent },
  { path: 'a_edit',    component: ViewAdmissionComponent},
  { path: 's',    component:StudentComponent },
  { path: 'a',    component: AdmissionOfficerComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
