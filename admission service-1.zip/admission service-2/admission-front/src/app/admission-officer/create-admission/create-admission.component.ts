import { Component, OnInit } from '@angular/core';
import { Admission } from 'src/app/admission';
import { ApiService } from 'src/app/api.service';


@Component({
  selector: 'app-create-admission',
  templateUrl: './create-admission.component.html',
  styleUrls: ['./create-admission.component.css']
})
export class CreateAdmissionComponent implements OnInit {

    stud : Admission= {
      studentname: "",
      fathername: "",
      mothername: "",
      student10thdetails: null,
      studentintermediatedetails: null,
      dateofbirth :null,
      joiningbranch: "",
      
    };
    constructor(private service: ApiService) { }
    ngOnInit() {
    } 
    create() {
      console.log(this.stud);
     this.service.create(this.stud).subscribe(res => {
        console.log(res)     
     })
    }
  
  }
  
  
  