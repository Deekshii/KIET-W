import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,  ReactiveFormsModule } from '@angular/forms';
 import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { ManagementComponent } from './management/management.component';
import { StudentComponent } from './student/student.component';
import { ViewStudentComponent } from './student/view-student/view-student.component';

import { LibrarianComponent } from './librarian/librarian.component';

import { CreateLibrarianComponent } from './librarian/create-librarian/create-librarian.component';
import { ViewLibrarianComponent } from './librarian/view-librarian/view-librarian.component';
import { ViewManagementComponent } from './management/view-management/view-management.component';


@NgModule({
  declarations: [
    AppComponent,
 
    ManagementComponent,
    StudentComponent,
    ViewStudentComponent,
    
    LibrarianComponent,
    
    CreateLibrarianComponent,
    ViewLibrarianComponent,
    ViewManagementComponent,
 
  ],
  imports: [
    BrowserModule,
    NgbModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
