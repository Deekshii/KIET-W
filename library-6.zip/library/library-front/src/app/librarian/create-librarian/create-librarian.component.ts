import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/api.service';
import { Library } from 'src/app/library';

@Component({
  selector: 'app-create-librarian',
  templateUrl: './create-librarian.component.html',
  styleUrls: ['./create-librarian.component.css']
})
export class CreateLibrarianComponent implements OnInit {

  stud : Library= {
    booksavailable: "",
    studentname: "", 
    dateofissue: null,
    subjectname: "",
    studentemail: "",
    studentclass: "",
    studentbranch: "",
    studentsection: "",
    
  };
  constructor(private service: ApiService) { }
  ngOnInit() {
  } 
  create() {
    console.log(this.stud);
   this.service.create(this.stud).subscribe(res => {
      console.log(res)     
   })
  }

}



